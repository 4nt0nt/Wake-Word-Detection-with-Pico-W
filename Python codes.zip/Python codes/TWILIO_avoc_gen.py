import time
import network
import urequests

import constants


def call_number(ssid, password, recipient, sender,
                twiml, auth_token, account_sid):
    """
        Description: This is a function to call someone with a twilio number.
        
        Parameters:
        
        ssid[str]: The name of your internet connection
        password[str]: Password for your internet connection
        recipient[str]: Phone number of recipient
        sender[str]: Phone number for twilio account
        twiml[str]: a URL that hosts a set of TwiML instructions
            (this could be an XML document or web application) or
            the set of URLs and configuration you've created as an
            application in the Twilio console
        auth_token[str]: Token from twilio profile
        account_sid[str]: Sid from twilio profile
    """
    # Just making our internet connection
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)

    # Wait for connect or fail
    max_wait = 10
    while max_wait > 0:
      if wlan.status() < 0 or wlan.status() >= 3:
        break
      max_wait -= 1
      print('waiting for connection...')
      time.sleep(1)
    # Handle connection error
    if wlan.status() != 3:
       raise RuntimeError('network connection failed')
    else:
      print('connected')
      status = wlan.ifconfig()
      #print('ip = ' + status[0])
      
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    data = "To=" + recipient + "&From=" + sender + "&Url=" + twiml
    print("Attempting to Call User")
    r = urequests.post("https://api.twilio.com/2010-04-01/Accounts/" +
                       account_sid + "/Calls.json",
                       data=data,
                       auth=(account_sid,auth_token),
                       headers=headers)
    if r.status_code >= 300 or r.status_code < 200:
        print("There was an error with your request to send a message. \n" +
              "Response Status: " + str(r.status_code))
    else:
        print("Success")
        print(r.status_code)
    r.close()
    
    
# Set your Twilio account SID, auth token, and other details
account_sid = "your_twilio_account_sid"
auth_token = "your_twilio_auth_token"
ssid = "your_wifi_ssid"
password = "your_wifi_password"

# Set the recipient's and sender's phone numbers
recipient_number = "recipient_phone_number"
sender_number = "your_twilio_phone_number"

# Set the TwiML URL (replace with your own TwiML URL)
twiml_url = "https://example.com/your-twiml-file.xml"

# Call the function to initiate the automated voice call
call_number(ssid, password, recipient_number, sender_number, twiml_url, auth_token, account_sid)

# Allow some time for the call to be initiated (adjust as needed)
time.sleep(30)
