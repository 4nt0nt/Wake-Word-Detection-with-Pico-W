from machine import Pin, ADC
import time

# Define ADC pin
adc_pin = ADC(Pin(26))  # Change the pin number based on your wiring

# List to store analog values
analog_values = []

# Record data for 10 seconds
end_time = time.ticks_ms() + 10000  # 10000 milliseconds = 10 seconds

# Main loop
while time.ticks_ms() < end_time:
    # Read 16-bit unsigned integer value from the ADC
    analog_value = adc_pin.read_u16()

    # Print and store the analog value
    print("Analog Value:", analog_value)
    analog_values.append(analog_value)

    # Adjust the delay based on your application
    time.sleep_ms(500)

# Display total number of recorded values
print("Recording complete. Total values:", len(analog_values))


