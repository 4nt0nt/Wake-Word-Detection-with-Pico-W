from pydub import AudioSegment
import array

# Read the raw audio data from the file
file_name = "audio_data.bin"
with open(file_name, "rb") as file:
    raw_audio_data = file.read()

# Convert raw audio data to AudioSegment
audio_segment = AudioSegment(
    raw_audio_data,
    sample_width=2,  # 16-bit samples, 2 bytes per sample
    frame_rate=44100,
    channels=1  # adjust for stereo audio
)

# Save the AudioSegment as an MP3 file
mp3_file_name = "audio_data.mp3"
audio_segment.export(mp3_file_name, format="mp3")

print("MP3 file saved:", mp3_file_name)

