# Imports
import wifi 
from wifi import radio
import array
import python_speech_features as psf
import model # custom model
import socket
import time

# WiFi Setup 
ssid = "wow"  
passwd = "what"

# Audio Configuration
sample_rate = 16000 
resolution = 12

# Connect to WiFi
radio.connect(ssid, passwd)

# Main Loop
while True:

    # Record Audio 
    buffer = array(480)
    mic.readinto(buffer)  

    # Feature Extraction
    mfccs = psf.mfcc(buffer, sample_rate)
    
    # Wake Word Detection
    if model.predict(mfccs)>0.9:
        print("Wake Word Detected!")
        
        # Connect WiFi and Send Notification
        radio.connect(ssid, passwd)
        socket.socket()
        socket.send("Wake word heard at "+ str(time)+"!")
