import array
import wave

# Read the raw audio data from the file
file_name = "audio_data.bin"
with open(file_name, "rb") as file:
    raw_audio_data = file.read()

# Convert raw audio data to WAV format
wav_file_name = "audio_data.wav"
with wave.open(wav_file_name, "wb") as wav_file:
    wav_file.setnchannels(1)  # Adjust for stereo audio
    wav_file.setsampwidth(2)  # 16-bit samples, 2 bytes per sample
    wav_file.setframerate(44100)  # Adjust the frame rate as needed
    wav_file.writeframes(raw_audio_data)

print("WAV file saved:", wav_file_name)

